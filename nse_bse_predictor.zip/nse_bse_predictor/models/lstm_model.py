"""
lstm_model.py
-------------
Layers 7–12 – Input → LSTM → Dropout → Dense → Output → Training

Architecture
────────────
Input  (lookback, num_features)
  ↓
LSTM   (128 units, return_sequences=True)
  ↓
Dropout (0.2)
  ↓
LSTM   (64 units)
  ↓
Dropout (0.2)
  ↓
Dense  (32, relu)
  ↓
Dense  (1)   ← predicted close price (INR)
"""

import os
import numpy as np
import pickle

import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import (
    LSTM, Dense, Dropout, Input, BatchNormalization
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import (
    EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
)


def build_model(
    lookback: int,
    num_features: int,
    lstm_units_1: int = 128,
    lstm_units_2: int = 64,
    dense_units: int = 32,
    dropout_rate: float = 0.2,
    learning_rate: float = 0.001,
) -> tf.keras.Model:
    """
    Build and compile the stacked LSTM model.

    Parameters
    ----------
    lookback      : Input time-steps (e.g. 60 days)
    num_features  : Number of feature columns
    lstm_units_1  : Neurons in first LSTM layer
    lstm_units_2  : Neurons in second LSTM layer
    dense_units   : Neurons in intermediate Dense layer
    dropout_rate  : Fraction of neurons to randomly drop
    learning_rate : Adam learning rate

    Returns
    -------
    Compiled Keras model
    """
    model = Sequential([
        Input(shape=(lookback, num_features)),

        # ── First LSTM block ─────────────────────────────────────────────────
        LSTM(lstm_units_1, return_sequences=True, name="lstm_1"),
        BatchNormalization(),
        Dropout(dropout_rate, name="dropout_1"),

        # ── Second LSTM block ────────────────────────────────────────────────
        LSTM(lstm_units_2, return_sequences=False, name="lstm_2"),
        BatchNormalization(),
        Dropout(dropout_rate, name="dropout_2"),

        # ── Fully connected decision layers ──────────────────────────────────
        Dense(dense_units, activation="relu", name="dense_1"),
        Dropout(dropout_rate / 2, name="dropout_3"),

        # ── Output: single predicted price ───────────────────────────────────
        Dense(1, name="output"),
    ], name="NSE_BSE_LSTM")

    model.compile(
        optimizer=Adam(learning_rate=learning_rate),
        loss="mean_squared_error",
        metrics=["mae"],
    )

    model.summary()
    return model


def train_model(
    model: tf.keras.Model,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    epochs: int = 100,
    batch_size: int = 32,
    model_save_path: str = "models/lstm_model.keras",
) -> dict:
    """
    Train the model with early stopping, LR reduction, and checkpoint saving.

    Returns
    -------
    dict with 'model' (best weights loaded) and 'history' Keras history object
    """
    os.makedirs(os.path.dirname(model_save_path), exist_ok=True)

    callbacks = [
        EarlyStopping(
            monitor="val_loss",
            patience=15,
            restore_best_weights=True,
            verbose=1,
        ),
        ModelCheckpoint(
            filepath=model_save_path,
            monitor="val_loss",
            save_best_only=True,
            verbose=1,
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=7,
            min_lr=1e-6,
            verbose=1,
        ),
    ]

    print(f"\n[LSTM] Starting training: {epochs} max epochs, "
          f"batch_size={batch_size}")
    print(f"[LSTM] Train samples: {len(X_train)} | Val samples: {len(X_val)}")

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=1,
    )

    print(f"[LSTM] Training complete. Best val_loss: "
          f"{min(history.history['val_loss']):.4f}")
    return {"model": model, "history": history}


def load_trained_model(path: str = "models/lstm_model.keras") -> tf.keras.Model:
    """Load a saved Keras model."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"No model found at '{path}'. Train first.")
    return load_model(path)
