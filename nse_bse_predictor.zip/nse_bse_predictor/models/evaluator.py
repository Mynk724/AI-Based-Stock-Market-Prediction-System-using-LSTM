"""
evaluator.py
------------
Layer 14 – Evaluation
Computes RMSE, MAE, MAPE, and R² for predictions vs actuals.
Also generates the 'next day' forecast for live use.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


def evaluate_predictions(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    verbose: bool = True,
) -> dict:
    """
    Compute regression metrics.

    Parameters
    ----------
    y_true : Actual close prices (INR)
    y_pred : Predicted close prices (INR)

    Returns
    -------
    dict: rmse, mae, mape, r2
    """
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae  = mean_absolute_error(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-10))) * 100
    r2   = r2_score(y_true, y_pred)

    metrics = {"RMSE": rmse, "MAE": mae, "MAPE (%)": mape, "R²": r2}

    if verbose:
        print("\n── Evaluation Metrics ──────────────────────────────────")
        for k, v in metrics.items():
            print(f"  {k:<12}: {v:.4f}")
        print("────────────────────────────────────────────────────────\n")

    return metrics


def predict_next_day(
    model,
    df_featured: pd.DataFrame,
    scaler,
    feature_cols: list,
    lookback: int = 60,
) -> float:
    """
    Predict the NEXT trading day's closing price using the most recent window.

    Parameters
    ----------
    model         : Trained Keras model
    df_featured   : Feature-engineered DataFrame (full history)
    scaler        : Fitted MinMaxScaler
    feature_cols  : List of feature column names
    lookback      : Window size used during training

    Returns
    -------
    float: Predicted closing price in INR
    """
    recent = df_featured[feature_cols].values[-lookback:]  # (lookback, feats)
    recent_scaled = scaler.transform(recent)               # scale
    X_next = recent_scaled[np.newaxis, :, :]               # (1, lookback, feats)

    pred = model.predict(X_next, verbose=0)[0][0]          # raw INR value
    return float(pred)


def direction_accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """
    Percentage of days where the model correctly predicted the direction
    (up or down) of price movement.
    """
    true_dir = np.sign(np.diff(y_true))
    pred_dir = np.sign(np.diff(y_pred))
    acc = np.mean(true_dir == pred_dir) * 100
    print(f"[Evaluator] Direction accuracy: {acc:.1f}%")
    return acc
