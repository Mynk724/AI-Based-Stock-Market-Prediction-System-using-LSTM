"""
train.py
--------
Master training script – runs all layers end-to-end.

Usage
-----
python train.py --ticker RELIANCE.NS --period 5y --lookback 60 --epochs 100

Quick start:
  python train.py                          # defaults to RELIANCE.NS
  python train.py --ticker TCS.NS
  python train.py --ticker HDFCBANK.BO --exchange BSE
"""

import argparse
import os
import sys
import pickle
import numpy as np

# ── Path fix so sub-packages resolve when run from project root ───────────────
sys.path.insert(0, os.path.dirname(__file__))

from data.data_collector   import fetch_stock_data, save_raw_data
from data.data_preprocessor import preprocess
from data.feature_engineer  import add_features, get_feature_columns
from data.data_pipeline     import normalize_and_split
from models.lstm_model      import build_model, train_model
from models.evaluator       import evaluate_predictions, direction_accuracy


def run_training(
    ticker:     str   = "RELIANCE.NS",
    period:     str   = "5y",
    lookback:   int   = 60,
    epochs:     int   = 100,
    batch_size: int   = 32,
    train_ratio: float = 0.80,
    lr:         float = 0.001,
):
    print("\n" + "═" * 60)
    print(f"  NSE/BSE LSTM Stock Predictor")
    print(f"  Ticker  : {ticker}")
    print(f"  Period  : {period}  |  Lookback: {lookback} days")
    print("═" * 60 + "\n")

    # ── Layer 1: Data Collection ──────────────────────────────────────────────
    print("▶ Layer 1 – Collecting data …")
    df_raw = fetch_stock_data(ticker, period=period)
    save_raw_data(df_raw, ticker)

    # ── Layer 2: Preprocessing ────────────────────────────────────────────────
    print("\n▶ Layer 2 – Preprocessing …")
    df_clean = preprocess(df_raw)

    # ── Layer 3: Feature Engineering ─────────────────────────────────────────
    print("\n▶ Layer 3 – Feature Engineering …")
    df_feat = add_features(df_clean)

    # ── Layers 4-6: Normalize + Sequences + Split ─────────────────────────────
    print("\n▶ Layers 4-6 – Normalize → Sequences → Split …")
    pipeline = normalize_and_split(
        df_feat,
        lookback=lookback,
        train_ratio=train_ratio,
        scaler_path=f"models/{ticker.replace('.','_')}_scaler.pkl",
    )

    X_train = pipeline["X_train"]
    y_train = pipeline["y_train"]
    X_test  = pipeline["X_test"]
    y_test  = pipeline["y_test"]

    # Use last 10% of training set as validation
    val_split  = int(len(X_train) * 0.9)
    X_val      = X_train[val_split:]
    y_val      = y_train[val_split:]
    X_train    = X_train[:val_split]
    y_train    = y_train[:val_split]

    # ── Layers 7-12: Build + Train Model ─────────────────────────────────────
    print("\n▶ Layers 7-12 – Building LSTM model …")
    model = build_model(
        lookback=lookback,
        num_features=X_train.shape[2],
        learning_rate=lr,
    )

    model_path = f"models/{ticker.replace('.','_')}_lstm.keras"
    result = train_model(
        model, X_train, y_train, X_val, y_val,
        epochs=epochs,
        batch_size=batch_size,
        model_save_path=model_path,
    )
    trained_model = result["model"]
    history       = result["history"]

    # ── Layer 13: Prediction ──────────────────────────────────────────────────
    print("\n▶ Layer 13 – Generating test-set predictions …")
    y_pred = trained_model.predict(X_test, verbose=0).flatten()

    # ── Layer 14: Evaluation ──────────────────────────────────────────────────
    print("\n▶ Layer 14 – Evaluating …")
    metrics = evaluate_predictions(y_test, y_pred)
    direction_accuracy(y_test, y_pred)

    # Save training metadata for Streamlit app
    meta = {
        "ticker":       ticker,
        "lookback":     lookback,
        "feature_cols": pipeline["feature_cols"],
        "target_col":   pipeline["target_col"],
        "metrics":      metrics,
        "dates_test":   pipeline["dates_test"],
        "y_test":       y_test,
        "y_pred":       y_pred,
        "history":      {k: [float(v) for v in vals]
                         for k, vals in history.history.items()},
    }
    meta_path = f"models/{ticker.replace('.','_')}_meta.pkl"
    with open(meta_path, "wb") as f:
        pickle.dump(meta, f)
    print(f"\n[Train] Metadata saved → {meta_path}")

    print("\n" + "═" * 60)
    print("  ✅  Training complete!")
    print(f"  Model  : {model_path}")
    print(f"  RMSE   : ₹{metrics['RMSE']:.2f}")
    print(f"  MAE    : ₹{metrics['MAE']:.2f}")
    print(f"  R²     : {metrics['R²']:.4f}")
    print("═" * 60 + "\n")
    return meta


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train LSTM on NSE/BSE stock data")
    parser.add_argument("--ticker",      default="RELIANCE.NS", help="e.g. TCS.NS or HDFCBANK.BO")
    parser.add_argument("--period",      default="5y",          help="yfinance period: 1y/2y/5y/10y/max")
    parser.add_argument("--lookback",    default=60,  type=int, help="Days in input window")
    parser.add_argument("--epochs",      default=100, type=int, help="Max training epochs")
    parser.add_argument("--batch_size",  default=32,  type=int, help="Batch size")
    parser.add_argument("--train_ratio", default=0.80,type=float,help="Train/test split ratio")
    parser.add_argument("--lr",          default=0.001,type=float,help="Learning rate")
    args = parser.parse_args()

    run_training(
        ticker=args.ticker,
        period=args.period,
        lookback=args.lookback,
        epochs=args.epochs,
        batch_size=args.batch_size,
        train_ratio=args.train_ratio,
        lr=args.lr,
    )
