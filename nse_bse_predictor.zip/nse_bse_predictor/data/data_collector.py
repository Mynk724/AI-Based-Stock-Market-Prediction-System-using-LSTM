"""
data_collector.py
-----------------
Layer 1 – Data Collection
Fetches historical OHLCV data for NSE/BSE stocks using yfinance.

NSE ticker format : RELIANCE.NS
BSE ticker format : RELIANCE.BO
"""

import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
import os

# ── Popular NSE stocks (add more as needed) ──────────────────────────────────
NSE_POPULAR = {
    "Reliance Industries": "RELIANCE.NS",
    "TCS": "TCS.NS",
    "HDFC Bank": "HDFCBANK.NS",
    "Infosys": "INFY.NS",
    "ICICI Bank": "ICICIBANK.NS",
    "Hindustan Unilever": "HINDUNILVR.NS",
    "Bajaj Finance": "BAJFINANCE.NS",
    "Kotak Mahindra Bank": "KOTAKBANK.NS",
    "Bharti Airtel": "BHARTIARTL.NS",
    "Wipro": "WIPRO.NS",
    "Adani Enterprises": "ADANIENT.NS",
    "Maruti Suzuki": "MARUTI.NS",
    "Sun Pharma": "SUNPHARMA.NS",
    "Axis Bank": "AXISBANK.NS",
    "Titan Company": "TITAN.NS",
    "Nifty 50 Index": "^NSEI",
    "Sensex Index": "^BSESN",
}

# ── Popular BSE stocks ────────────────────────────────────────────────────────
BSE_POPULAR = {
    "Reliance (BSE)": "RELIANCE.BO",
    "TCS (BSE)": "TCS.BO",
    "HDFC Bank (BSE)": "HDFCBANK.BO",
    "Infosys (BSE)": "INFY.BO",
}


def get_ticker_symbol(name: str, exchange: str = "NSE") -> str:
    """
    Returns the yfinance ticker for a given stock name and exchange.
    If the user types a raw ticker (e.g. 'RELIANCE.NS'), it is returned as-is.
    """
    suffix = ".NS" if exchange.upper() == "NSE" else ".BO"
    if "." in name:          # already has exchange suffix
        return name.upper()
    return name.upper() + suffix


def fetch_stock_data(
    ticker: str,
    start_date: str = None,
    end_date: str = None,
    period: str = "5y",
) -> pd.DataFrame:
    """
    Download OHLCV data from Yahoo Finance.

    Parameters
    ----------
    ticker     : e.g. 'RELIANCE.NS' or 'TCS.BO'
    start_date : 'YYYY-MM-DD'  (overrides period if provided)
    end_date   : 'YYYY-MM-DD'  (defaults to today)
    period     : yfinance period string – '1y','2y','5y','10y','max'

    Returns
    -------
    pd.DataFrame with columns: Open, High, Low, Close, Volume
    """
    try:
        stock = yf.Ticker(ticker)

        if start_date:
            end = end_date or datetime.today().strftime("%Y-%m-%d")
            df = stock.history(start=start_date, end=end)
        else:
            df = stock.history(period=period)

        if df.empty:
            raise ValueError(f"No data returned for ticker '{ticker}'. "
                             "Check the symbol or try a different period.")

        # Keep only OHLCV; drop timezone info from index
        df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
        df.index = pd.to_datetime(df.index).tz_localize(None)
        df.index.name = "Date"
        df.sort_index(inplace=True)

        print(f"[DataCollector] Fetched {len(df)} rows for {ticker} "
              f"({df.index[0].date()} → {df.index[-1].date()})")
        return df

    except Exception as exc:
        raise RuntimeError(f"[DataCollector] Failed to fetch data: {exc}") from exc


def save_raw_data(df: pd.DataFrame, ticker: str, save_dir: str = "data/raw") -> str:
    """Save raw OHLCV DataFrame to CSV."""
    os.makedirs(save_dir, exist_ok=True)
    safe_name = ticker.replace(".", "_").replace("^", "IDX_")
    path = os.path.join(save_dir, f"{safe_name}_raw.csv")
    df.to_csv(path)
    print(f"[DataCollector] Saved raw data → {path}")
    return path


def load_raw_data(ticker: str, save_dir: str = "data/raw") -> pd.DataFrame:
    """Load previously saved CSV for a ticker."""
    safe_name = ticker.replace(".", "_").replace("^", "IDX_")
    path = os.path.join(save_dir, f"{safe_name}_raw.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(f"No cached data found at {path}. "
                                "Run fetch_stock_data() first.")
    df = pd.read_csv(path, index_col="Date", parse_dates=True)
    return df


# ── Quick test ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    df = fetch_stock_data("RELIANCE.NS", period="2y")
    print(df.tail())
    save_raw_data(df, "RELIANCE.NS")
