"""
data_preprocessor.py
--------------------
Layer 2 – Data Preprocessing
Cleans raw OHLCV DataFrames before feature engineering.
"""

import pandas as pd
import numpy as np


def preprocess(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """
    Full preprocessing pipeline:
      1. Remove duplicate index entries
      2. Sort chronologically
      3. Forward-fill then back-fill small gaps (≤5 days)
      4. Drop rows still containing NaN after fill
      5. Remove zero/negative price rows (data errors)
      6. Reset to clean DatetimeIndex

    Parameters
    ----------
    df      : Raw OHLCV DataFrame (columns: Open, High, Low, Close, Volume)
    verbose : Print summary statistics

    Returns
    -------
    Cleaned pd.DataFrame
    """
    original_len = len(df)

    # ── 1. Ensure DatetimeIndex ──────────────────────────────────────────────
    df = df.copy()
    df.index = pd.to_datetime(df.index)
    df.index.name = "Date"

    # ── 2. Remove duplicates ─────────────────────────────────────────────────
    df = df[~df.index.duplicated(keep="last")]

    # ── 3. Sort chronologically ──────────────────────────────────────────────
    df.sort_index(inplace=True)

    # ── 4. Reindex to a complete business-day range & fill gaps ──────────────
    full_range = pd.bdate_range(start=df.index.min(), end=df.index.max())
    df = df.reindex(full_range)
    df.index.name = "Date"
    # Forward-fill up to 5 consecutive missing trading days (holiday windows)
    df.ffill(limit=5, inplace=True)
    df.bfill(limit=2, inplace=True)

    # ── 5. Drop remaining NaN rows ───────────────────────────────────────────
    df.dropna(inplace=True)

    # ── 6. Remove data errors (zero / negative prices) ───────────────────────
    for col in ["Open", "High", "Low", "Close"]:
        df = df[df[col] > 0]

    # ── 7. Clip extreme volume outliers (top 0.1%) ───────────────────────────
    vol_cap = df["Volume"].quantile(0.999)
    df["Volume"] = df["Volume"].clip(upper=vol_cap)

    if verbose:
        print(f"[Preprocessor] Rows before: {original_len} | after: {len(df)} "
              f"| dropped: {original_len - len(df)}")
        print(f"[Preprocessor] Date range : "
              f"{df.index[0].date()} → {df.index[-1].date()}")

    return df
