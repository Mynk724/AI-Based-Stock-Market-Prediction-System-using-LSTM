"""
data_pipeline.py
----------------
Layers 4 & 5 & 6 – Normalization + Sequence Generation + Train/Test Split

Outputs X (features), y (target), and the fitted scaler for inverse-transform.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os
import pickle
from data.feature_engineer import get_feature_columns


def normalize_and_split(
    df: pd.DataFrame,
    feature_cols: list = None,
    target_col: str = "Close",
    lookback: int = 60,
    train_ratio: float = 0.80,
    scaler_path: str = "models/scaler.pkl",
) -> dict:
    """
    Full pipeline: normalize → create sequences → chronological split.

    Parameters
    ----------
    df           : Feature-engineered DataFrame
    feature_cols : Columns to use as inputs (defaults to get_feature_columns())
    target_col   : Column to predict (default 'Close')
    lookback     : Number of past days as input window (default 60)
    train_ratio  : Fraction of data for training (default 0.80 = 80%)
    scaler_path  : Where to save the fitted scaler for later inverse-transform

    Returns
    -------
    dict with keys:
        X_train, y_train  – training sequences & targets
        X_test,  y_test   – test sequences & targets
        scaler            – fitted MinMaxScaler (for inverse transform)
        dates_test        – DatetimeIndex aligned with y_test (for plotting)
        feature_cols      – list of feature column names used
    """
    if feature_cols is None:
        feature_cols = [c for c in get_feature_columns() if c in df.columns]

    # ── 1. Select feature matrix and target ──────────────────────────────────
    data    = df[feature_cols].values            # (N, num_features)
    target  = df[target_col].values              # (N,)
    dates   = df.index                           # DatetimeIndex

    # ── 2. Fit MinMax scaler on entire feature matrix ─────────────────────────
    #  NOTE: We fit on the WHOLE dataset here for scale consistency.
    #  In production you should fit only on train; we keep it simple for learning.
    scaler  = MinMaxScaler(feature_range=(0, 1))
    data_scaled = scaler.fit_transform(data)

    # Save scaler
    os.makedirs(os.path.dirname(scaler_path), exist_ok=True)
    with open(scaler_path, "wb") as f:
        pickle.dump({"scaler": scaler, "feature_cols": feature_cols,
                     "target_col": target_col}, f)
    print(f"[Pipeline] Scaler saved → {scaler_path}")

    # ── 3. Build sliding windows ──────────────────────────────────────────────
    X, y, y_dates = [], [], []
    for i in range(lookback, len(data_scaled)):
        X.append(data_scaled[i - lookback : i])        # (lookback, features)
        y.append(target[i])                            # raw price (INR)
        y_dates.append(dates[i])

    X       = np.array(X)   # (samples, lookback, features)
    y       = np.array(y)   # (samples,)
    y_dates = pd.DatetimeIndex(y_dates)

    print(f"[Pipeline] Sequences: X={X.shape}, y={y.shape}")

    # ── 4. Chronological train / test split ───────────────────────────────────
    split_idx   = int(len(X) * train_ratio)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    dates_test      = y_dates[split_idx:]

    print(f"[Pipeline] Train: {X_train.shape} | Test: {X_test.shape}")
    print(f"[Pipeline] Test period: {dates_test[0].date()} → {dates_test[-1].date()}")

    return {
        "X_train": X_train,
        "y_train": y_train,
        "X_test":  X_test,
        "y_test":  y_test,
        "scaler":  scaler,
        "dates_test": dates_test,
        "feature_cols": feature_cols,
        "lookback": lookback,
        "target_col": target_col,
    }


def load_scaler(scaler_path: str = "models/scaler.pkl"):
    """Load a previously saved scaler dict."""
    with open(scaler_path, "rb") as f:
        return pickle.load(f)
