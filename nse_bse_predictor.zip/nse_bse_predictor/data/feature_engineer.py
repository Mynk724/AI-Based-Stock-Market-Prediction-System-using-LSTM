"""
feature_engineer.py
-------------------
Layer 3 – Feature Engineering
Adds technical indicators on top of OHLCV data using the `ta` library.

Indicators generated
────────────────────
Trend     : SMA_20, SMA_50, EMA_12, EMA_26
Momentum  : RSI_14, MACD, MACD_Signal, MACD_Hist, Stoch_K, Stoch_D
Volatility: BB_Upper, BB_Middle, BB_Lower, BB_Width, ATR_14
Volume    : OBV, VWAP (approximated daily)
Price     : Returns_1d, Returns_5d, High_Low_Ratio, Close_Open_Ratio
"""

import pandas as pd
import numpy as np

try:
    import ta
    TA_AVAILABLE = True
except ImportError:
    TA_AVAILABLE = False
    print("[FeatureEngineer] WARNING: 'ta' library not found. "
          "Run `pip install ta`. Using manual fallbacks.")


# ── Manual fallbacks (used when `ta` is absent) ───────────────────────────────

def _sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window=window).mean()

def _ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def _rsi(close: pd.Series, window: int = 14) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0).rolling(window).mean()
    loss  = (-delta.clip(upper=0)).rolling(window).mean()
    rs    = gain / (loss + 1e-10)
    return 100 - (100 / (1 + rs))


# ── Main function ─────────────────────────────────────────────────────────────

def add_features(df: pd.DataFrame, drop_na: bool = True) -> pd.DataFrame:
    """
    Compute and append all technical indicators to the OHLCV DataFrame.

    Parameters
    ----------
    df      : Preprocessed OHLCV DataFrame
    drop_na : If True, drop rows where any indicator is NaN (first ~50 rows)

    Returns
    -------
    pd.DataFrame with original OHLCV + all indicator columns
    """
    df = df.copy()
    close  = df["Close"]
    high   = df["High"]
    low    = df["Low"]
    open_  = df["Open"]
    volume = df["Volume"]

    # ── Trend ────────────────────────────────────────────────────────────────
    if TA_AVAILABLE:
        df["SMA_20"]      = ta.trend.sma_indicator(close, window=20)
        df["SMA_50"]      = ta.trend.sma_indicator(close, window=50)
        df["EMA_12"]      = ta.trend.ema_indicator(close, window=12)
        df["EMA_26"]      = ta.trend.ema_indicator(close, window=26)
    else:
        df["SMA_20"] = _sma(close, 20)
        df["SMA_50"] = _sma(close, 50)
        df["EMA_12"] = _ema(close, 12)
        df["EMA_26"] = _ema(close, 26)

    # ── Momentum ─────────────────────────────────────────────────────────────
    if TA_AVAILABLE:
        macd_obj          = ta.trend.MACD(close, window_slow=26,
                                          window_fast=12, window_sign=9)
        df["MACD"]        = macd_obj.macd()
        df["MACD_Signal"] = macd_obj.macd_signal()
        df["MACD_Hist"]   = macd_obj.macd_diff()
        df["RSI_14"]      = ta.momentum.RSIIndicator(close, window=14).rsi()
        stoch             = ta.momentum.StochasticOscillator(
                                high, low, close, window=14, smooth_window=3)
        df["Stoch_K"]     = stoch.stoch()
        df["Stoch_D"]     = stoch.stoch_signal()
    else:
        ema12 = _ema(close, 12); ema26 = _ema(close, 26)
        df["MACD"]        = ema12 - ema26
        df["MACD_Signal"] = _ema(df["MACD"], 9)
        df["MACD_Hist"]   = df["MACD"] - df["MACD_Signal"]
        df["RSI_14"]      = _rsi(close, 14)
        df["Stoch_K"]     = pd.Series(np.nan, index=df.index)
        df["Stoch_D"]     = pd.Series(np.nan, index=df.index)

    # ── Volatility ───────────────────────────────────────────────────────────
    if TA_AVAILABLE:
        bb                = ta.volatility.BollingerBands(
                                close, window=20, window_dev=2)
        df["BB_Upper"]    = bb.bollinger_hband()
        df["BB_Middle"]   = bb.bollinger_mavg()
        df["BB_Lower"]    = bb.bollinger_lband()
        df["BB_Width"]    = bb.bollinger_wband()
        df["ATR_14"]      = ta.volatility.AverageTrueRange(
                                high, low, close, window=14).average_true_range()
    else:
        sma20 = _sma(close, 20)
        std20 = close.rolling(20).std()
        df["BB_Upper"]  = sma20 + 2 * std20
        df["BB_Middle"] = sma20
        df["BB_Lower"]  = sma20 - 2 * std20
        df["BB_Width"]  = (df["BB_Upper"] - df["BB_Lower"]) / sma20
        tr = pd.concat([high - low,
                        (high - close.shift()).abs(),
                        (low  - close.shift()).abs()], axis=1).max(axis=1)
        df["ATR_14"] = tr.rolling(14).mean()

    # ── Volume ───────────────────────────────────────────────────────────────
    if TA_AVAILABLE:
        df["OBV"] = ta.volume.OnBalanceVolumeIndicator(close, volume).on_balance_volume()
    else:
        obv = (np.sign(close.diff()) * volume).fillna(0).cumsum()
        df["OBV"] = obv

    # Approximate daily VWAP  = (H+L+C)/3  × Volume  /  cumulative Volume
    tp = (high + low + close) / 3
    df["VWAP"] = (tp * volume).cumsum() / volume.cumsum()

    # ── Price-derived features ────────────────────────────────────────────────
    df["Returns_1d"]        = close.pct_change(1)
    df["Returns_5d"]        = close.pct_change(5)
    df["High_Low_Ratio"]    = (high - low) / (close + 1e-10)
    df["Close_Open_Ratio"]  = (close - open_) / (open_ + 1e-10)

    if drop_na:
        before = len(df)
        df.dropna(inplace=True)
        print(f"[FeatureEngineer] Dropped {before - len(df)} NaN rows after indicators.")

    print(f"[FeatureEngineer] Feature set ready: {df.shape[1]} columns, "
          f"{len(df)} rows.")
    return df


def get_feature_columns() -> list:
    """Return the ordered list of indicator columns used as model input."""
    return [
        "Open", "High", "Low", "Close", "Volume",
        "SMA_20", "SMA_50", "EMA_12", "EMA_26",
        "MACD", "MACD_Signal", "MACD_Hist", "RSI_14", "Stoch_K", "Stoch_D",
        "BB_Upper", "BB_Middle", "BB_Lower", "BB_Width", "ATR_14",
        "OBV", "VWAP",
        "Returns_1d", "Returns_5d", "High_Low_Ratio", "Close_Open_Ratio",
    ]
