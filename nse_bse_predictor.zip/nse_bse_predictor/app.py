"""
app.py  –  Streamlit Deployment Layer (Layer 16)
─────────────────────────────────────────────────
Run with:  streamlit run app.py

Features
────────
• Fetch & preview live NSE/BSE data
• Train a model right inside the browser
• View prediction charts (Actual vs Predicted)
• See loss curves, metrics, technical indicators
• Predict next-day closing price
"""

import os
import sys
import pickle
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime

sys.path.insert(0, os.path.dirname(__file__))

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="NSE/BSE Stock Predictor",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] { font-family: 'Space Grotesk', sans-serif; }
    .metric-card {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 1.2rem;
        text-align: center;
        margin: 0.3rem;
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; color: #38bdf8; }
    .metric-label { font-size: 0.8rem; color: #94a3b8; letter-spacing: 0.08em; text-transform: uppercase; }
    .signal-buy  { color: #4ade80; font-weight: 700; font-size: 1.1rem; }
    .signal-sell { color: #f87171; font-weight: 700; font-size: 1.1rem; }
    .signal-hold { color: #fbbf24; font-weight: 700; font-size: 1.1rem; }
    h1 { color: #f1f5f9 !important; }
    h2, h3 { color: #cbd5e1 !important; }
</style>
""", unsafe_allow_html=True)


# ── Imports that need path ────────────────────────────────────────────────────
from data.data_collector    import fetch_stock_data, NSE_POPULAR
from data.data_preprocessor import preprocess
from data.feature_engineer  import add_features, get_feature_columns
from data.data_pipeline     import normalize_and_split
from models.lstm_model      import build_model, train_model, load_trained_model
from models.evaluator       import evaluate_predictions, predict_next_day, direction_accuracy


# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════
st.sidebar.image("https://img.icons8.com/fluency/96/combo-chart--v2.png", width=60)
st.sidebar.title("NSE/BSE Predictor")
st.sidebar.markdown("*Deep Learning Stock Forecasting*")
st.sidebar.divider()

# Stock selection
exchange = st.sidebar.radio("Exchange", ["NSE", "BSE"], horizontal=True)
suffix   = ".NS" if exchange == "NSE" else ".BO"

popular_map = {k: v for k, v in NSE_POPULAR.items()
               if (suffix in v or "IDX" in v.replace("^", "IDX_"))}
popular_map["Custom ticker …"] = "CUSTOM"

stock_choice = st.sidebar.selectbox("Select Stock", list(popular_map.keys()))

if stock_choice == "Custom ticker …":
    raw_ticker = st.sidebar.text_input("Enter ticker (e.g. WIPRO.NS)")
    ticker = raw_ticker.upper().strip()
else:
    ticker = popular_map[stock_choice]

period   = st.sidebar.selectbox("Data Period", ["2y","3y","5y","10y","max"], index=2)
lookback = st.sidebar.slider("Lookback Window (days)", 30, 120, 60, step=10)

st.sidebar.divider()
st.sidebar.subheader("Model Settings")
epochs     = st.sidebar.slider("Max Epochs",   20, 200, 100, step=10)
batch_size = st.sidebar.selectbox("Batch Size", [16, 32, 64], index=1)
lr         = st.sidebar.select_slider("Learning Rate",
                                      options=[0.0001, 0.0005, 0.001, 0.005],
                                      value=0.001)

st.sidebar.divider()
st.sidebar.caption("⚠️ Stock predictions are for educational purposes only. "
                   "Not financial advice.")


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════
def get_model_paths(t):
    safe = t.replace(".", "_").replace("^", "IDX_")
    return (f"models/{safe}_lstm.keras",
            f"models/{safe}_scaler.pkl",
            f"models/{safe}_meta.pkl")


def metric_card(label, value, unit=""):
    return f"""
    <div class="metric-card">
      <div class="metric-value">{value}{unit}</div>
      <div class="metric-label">{label}</div>
    </div>"""


def trading_signal(current_price, predicted_price, rsi_val):
    """Simple rule-based signal from prediction + RSI."""
    change_pct = (predicted_price - current_price) / current_price * 100
    if change_pct > 0.5 and rsi_val < 70:
        return "BUY 🟢", change_pct
    elif change_pct < -0.5 or rsi_val > 75:
        return "SELL 🔴", change_pct
    else:
        return "HOLD 🟡", change_pct


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN PAGE
# ═══════════════════════════════════════════════════════════════════════════════
st.title("📈 NSE / BSE LSTM Stock Predictor")
st.markdown(f"**Ticker:** `{ticker}`  |  **Exchange:** {exchange}  |  **Period:** {period}")

tabs = st.tabs(["📊 Data Explorer", "🏋️ Train Model", "🔮 Predict", "📉 Evaluation"])


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 – DATA EXPLORER
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[0]:
    st.subheader("Live Market Data")
    if not ticker:
        st.warning("Enter a ticker in the sidebar.")
        st.stop()

    with st.spinner(f"Fetching {ticker} data …"):
        try:
            df_raw   = fetch_stock_data(ticker, period=period)
            df_clean = preprocess(df_raw, verbose=False)
            df_feat  = add_features(df_clean, drop_na=True)
        except Exception as e:
            st.error(f"Error: {e}")
            st.stop()

    # ── Summary metrics ───────────────────────────────────────────────────────
    latest   = df_feat.iloc[-1]
    prev     = df_feat.iloc[-2]
    chg      = latest["Close"] - prev["Close"]
    chg_pct  = chg / prev["Close"] * 100
    chg_col  = "#4ade80" if chg >= 0 else "#f87171"

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.metric("Close Price", f"₹{latest['Close']:.2f}",
                  f"{chg:+.2f} ({chg_pct:+.1f}%)")
    with c2:
        st.metric("RSI (14)", f"{latest['RSI_14']:.1f}")
    with c3:
        st.metric("MACD", f"{latest['MACD']:.2f}")
    with c4:
        st.metric("Volume", f"{int(latest['Volume']):,}")
    with c5:
        st.metric("ATR (14)", f"₹{latest['ATR_14']:.2f}")

    # ── Candlestick + Volume chart ────────────────────────────────────────────
    st.markdown("#### Price Chart with Bollinger Bands")
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                        row_heights=[0.6, 0.2, 0.2],
                        vertical_spacing=0.04)

    display = df_feat.tail(252)  # last 1 year

    fig.add_trace(go.Candlestick(
        x=display.index, open=display["Open"], high=display["High"],
        low=display["Low"], close=display["Close"],
        name="OHLC",
        increasing_line_color="#4ade80",
        decreasing_line_color="#f87171",
    ), row=1, col=1)

    for band, color, dash in [
        ("BB_Upper",  "rgba(99,179,237,0.6)",  "dot"),
        ("BB_Middle", "rgba(99,179,237,0.9)",  "solid"),
        ("BB_Lower",  "rgba(99,179,237,0.6)",  "dot"),
    ]:
        fig.add_trace(go.Scatter(
            x=display.index, y=display[band],
            line=dict(color=color, width=1, dash=dash),
            name=band, showlegend=False,
        ), row=1, col=1)

    # RSI
    fig.add_trace(go.Scatter(
        x=display.index, y=display["RSI_14"],
        line=dict(color="#a78bfa", width=1.5), name="RSI"),
        row=2, col=1)
    fig.add_hline(y=70, line=dict(color="#f87171", dash="dash", width=1), row=2, col=1)
    fig.add_hline(y=30, line=dict(color="#4ade80", dash="dash", width=1), row=2, col=1)

    # Volume
    colors = ["#4ade80" if c >= o else "#f87171"
              for c, o in zip(display["Close"], display["Open"])]
    fig.add_trace(go.Bar(
        x=display.index, y=display["Volume"],
        marker_color=colors, name="Volume", showlegend=False,
    ), row=3, col=1)

    fig.update_layout(
        template="plotly_dark",
        height=650,
        xaxis_rangeslider_visible=False,
        paper_bgcolor="#0f172a",
        plot_bgcolor="#0f172a",
        font=dict(family="Space Grotesk"),
        margin=dict(l=40, r=40, t=30, b=20),
    )
    fig.update_yaxes(gridcolor="#1e293b", zerolinecolor="#1e293b")
    st.plotly_chart(fig, use_container_width=True)

    # ── Raw data table ────────────────────────────────────────────────────────
    with st.expander("📋 View Raw OHLCV Data"):
        st.dataframe(df_feat[["Open","High","Low","Close","Volume",
                               "RSI_14","MACD","BB_Upper","BB_Lower"]
                             ].tail(30).style.format("{:.2f}"),
                     use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 – TRAIN
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[1]:
    st.subheader("Train LSTM Model")
    model_path, scaler_path, meta_path = get_model_paths(ticker)

    if os.path.exists(meta_path):
        st.success(f"✅ Trained model found for **{ticker}**. "
                   "You can re-train or jump to Predict tab.")

    col_a, col_b = st.columns([2, 1])
    with col_a:
        st.markdown("""
        **What happens when you click Train:**
        1. Downloads OHLCV data from Yahoo Finance  
        2. Cleans & preprocesses the data  
        3. Computes 26 technical indicators  
        4. Normalises features (Min-Max 0→1)  
        5. Builds 60-day sliding windows  
        6. Splits 80% train / 20% test (no shuffle)  
        7. Trains a 2-layer stacked LSTM  
        8. Saves best model via Early Stopping  
        9. Evaluates on test set & saves results  
        """)
    with col_b:
        st.markdown("**Current config:**")
        st.json({
            "ticker":    ticker,
            "period":    period,
            "lookback":  lookback,
            "epochs":    epochs,
            "batch":     batch_size,
            "lr":        lr,
        })

    if st.button("🚀 Start Training", type="primary", use_container_width=True):
        progress_bar = st.progress(0, text="Initialising …")
        log_box      = st.empty()
        logs         = []

        def log(msg):
            logs.append(msg)
            log_box.code("\n".join(logs[-20:]))  # show last 20 lines

        try:
            progress_bar.progress(10, "Fetching data …")
            log(f"[1/9] Fetching {ticker} – {period} …")
            df_raw = fetch_stock_data(ticker, period=period)
            log(f"      → {len(df_raw)} rows fetched")

            progress_bar.progress(25, "Preprocessing …")
            log("[2/9] Preprocessing …")
            df_clean = preprocess(df_raw, verbose=False)

            progress_bar.progress(35, "Feature engineering …")
            log("[3/9] Computing 26 technical indicators …")
            df_feat = add_features(df_clean, drop_na=True)
            log(f"      → {df_feat.shape[1]} feature columns")

            progress_bar.progress(45, "Normalising & creating sequences …")
            log("[4-6/9] Normalising → Sequences → Split …")
            pipeline = normalize_and_split(
                df_feat, lookback=lookback,
                scaler_path=scaler_path,
            )
            X_train = pipeline["X_train"]
            y_train = pipeline["y_train"]
            X_test  = pipeline["X_test"]
            y_test  = pipeline["y_test"]
            val_split = int(len(X_train) * 0.9)
            X_val, y_val = X_train[val_split:], y_train[val_split:]
            X_train, y_train = X_train[:val_split], y_train[:val_split]
            log(f"      → Train: {X_train.shape}, Val: {X_val.shape}, "
                f"Test: {X_test.shape}")

            progress_bar.progress(55, "Building model …")
            log("[7/9] Building LSTM model …")
            model = build_model(
                lookback=lookback,
                num_features=X_train.shape[2],
                learning_rate=lr,
            )

            progress_bar.progress(60, "Training … (may take a few minutes)")
            log(f"[8/9] Training {epochs} max epochs …")
            result = train_model(
                model, X_train, y_train, X_val, y_val,
                epochs=epochs, batch_size=batch_size,
                model_save_path=model_path,
            )
            trained = result["model"]
            history = result["history"]
            best_loss = min(history.history["val_loss"])
            log(f"      → Best val_loss: {best_loss:.4f}")

            progress_bar.progress(85, "Evaluating …")
            log("[9/9] Evaluating on test set …")
            y_pred   = trained.predict(X_test, verbose=0).flatten()
            metrics  = evaluate_predictions(y_test, y_pred, verbose=False)
            dir_acc  = direction_accuracy(y_test, y_pred)

            # Save metadata
            meta = {
                "ticker": ticker, "lookback": lookback,
                "feature_cols": pipeline["feature_cols"],
                "target_col":   pipeline["target_col"],
                "metrics":  metrics,
                "dates_test": pipeline["dates_test"],
                "y_test":  y_test,
                "y_pred":  y_pred,
                "history": {k: [float(v) for v in vals]
                            for k, vals in history.history.items()},
                "dir_accuracy": dir_acc,
            }
            with open(meta_path, "wb") as f:
                pickle.dump(meta, f)

            progress_bar.progress(100, "Done!")
            log("✅ Training complete!")
            st.success(f"Model trained! RMSE=₹{metrics['RMSE']:.2f}  "
                       f"MAE=₹{metrics['MAE']:.2f}  R²={metrics['R²']:.4f}")
            st.balloons()

        except Exception as e:
            st.error(f"Training failed: {e}")
            import traceback; st.code(traceback.format_exc())


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 – PREDICT
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[2]:
    st.subheader("🔮 Next-Day Prediction")
    model_path, scaler_path, meta_path = get_model_paths(ticker)

    if not os.path.exists(model_path):
        st.info("👈 Train a model first using the **Train Model** tab.")
    else:
        with st.spinner("Loading model & computing prediction …"):
            try:
                trained_model = load_trained_model(model_path)
                scaler_info   = pickle.load(open(scaler_path, "rb"))
                meta          = pickle.load(open(meta_path,   "rb"))
                df_raw   = fetch_stock_data(ticker, period="1y")
                df_clean = preprocess(df_raw, verbose=False)
                df_feat  = add_features(df_clean, drop_na=True)

                scaler       = scaler_info["scaler"]
                feature_cols = scaler_info["feature_cols"]

                predicted_price = predict_next_day(
                    trained_model, df_feat, scaler,
                    feature_cols=feature_cols,
                    lookback=meta["lookback"],
                )
                current_price = float(df_feat["Close"].iloc[-1])
                rsi_now       = float(df_feat["RSI_14"].iloc[-1])
                signal, chg_pct = trading_signal(current_price, predicted_price, rsi_now)

            except Exception as e:
                st.error(f"Prediction error: {e}")
                st.stop()

        # ── Prediction cards ──────────────────────────────────────────────────
        st.markdown("#### Prediction Summary")
        pc1, pc2, pc3, pc4 = st.columns(4)
        with pc1:
            st.metric("Current Price",  f"₹{current_price:.2f}")
        with pc2:
            st.metric("Predicted (Next Day)", f"₹{predicted_price:.2f}",
                      f"{chg_pct:+.2f}%")
        with pc3:
            st.metric("RSI (14)",  f"{rsi_now:.1f}")
        with pc4:
            st.metric("Signal", signal)

        # ── Last 60-day chart with prediction point ───────────────────────────
        st.markdown("#### Last 60 Days + Next-Day Forecast")
        recent = df_feat["Close"].tail(60)
        next_date = recent.index[-1] + pd.tseries.offsets.BDay(1)

        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(
            x=recent.index, y=recent.values,
            mode="lines", name="Actual Close",
            line=dict(color="#38bdf8", width=2),
        ))
        fig2.add_trace(go.Scatter(
            x=[recent.index[-1], next_date],
            y=[current_price, predicted_price],
            mode="lines+markers",
            name="Predicted",
            line=dict(color="#fbbf24", width=2.5, dash="dot"),
            marker=dict(size=[6, 12], color=["#38bdf8", "#fbbf24"]),
        ))
        fig2.add_annotation(
            x=next_date, y=predicted_price,
            text=f"₹{predicted_price:.2f}",
            showarrow=True, arrowhead=2,
            arrowcolor="#fbbf24", font=dict(color="#fbbf24", size=14),
            bgcolor="#0f172a", bordercolor="#fbbf24",
        )
        fig2.update_layout(
            template="plotly_dark", height=380,
            paper_bgcolor="#0f172a", plot_bgcolor="#0f172a",
            font=dict(family="Space Grotesk"),
            margin=dict(l=40, r=40, t=30, b=20),
        )
        fig2.update_yaxes(gridcolor="#1e293b")
        st.plotly_chart(fig2, use_container_width=True)

        st.caption(
            "⚠️ This is an ML model output for educational purposes. "
            "Do not use for actual trading decisions."
        )


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4 – EVALUATION
# ═══════════════════════════════════════════════════════════════════════════════
with tabs[3]:
    st.subheader("📉 Model Evaluation")
    _, _, meta_path = get_model_paths(ticker)

    if not os.path.exists(meta_path):
        st.info("Train a model first to see evaluation results.")
    else:
        meta = pickle.load(open(meta_path, "rb"))
        m    = meta["metrics"]

        # ── Metric row ────────────────────────────────────────────────────────
        st.markdown("#### Performance Metrics on Test Set")
        mc1, mc2, mc3, mc4 = st.columns(4)
        with mc1:
            st.metric("RMSE", f"₹{m['RMSE']:.2f}")
        with mc2:
            st.metric("MAE",  f"₹{m['MAE']:.2f}")
        with mc3:
            st.metric("MAPE", f"{m['MAPE (%)']:.2f}%")
        with mc4:
            st.metric("R²",   f"{m['R²']:.4f}")
        if "dir_accuracy" in meta:
            st.metric("Direction Accuracy", f"{meta['dir_accuracy']:.1f}%")

        # ── Actual vs Predicted ───────────────────────────────────────────────
        st.markdown("#### Actual vs Predicted Close Prices")
        dates = meta["dates_test"]
        fig3  = go.Figure()
        fig3.add_trace(go.Scatter(
            x=dates, y=meta["y_test"],
            name="Actual",
            line=dict(color="#38bdf8", width=2),
        ))
        fig3.add_trace(go.Scatter(
            x=dates, y=meta["y_pred"],
            name="Predicted",
            line=dict(color="#fbbf24", width=1.5, dash="dot"),
        ))
        fig3.update_layout(
            template="plotly_dark", height=400,
            paper_bgcolor="#0f172a", plot_bgcolor="#0f172a",
            font=dict(family="Space Grotesk"),
            legend=dict(orientation="h", yanchor="bottom", y=1.02),
            margin=dict(l=40, r=40, t=40, b=20),
        )
        fig3.update_yaxes(gridcolor="#1e293b", title="Price (₹)")
        st.plotly_chart(fig3, use_container_width=True)

        # ── Loss curves ───────────────────────────────────────────────────────
        st.markdown("#### Training & Validation Loss")
        h    = meta["history"]
        fig4 = go.Figure()
        fig4.add_trace(go.Scatter(
            y=h["loss"], name="Train Loss",
            line=dict(color="#818cf8", width=2),
        ))
        fig4.add_trace(go.Scatter(
            y=h["val_loss"], name="Val Loss",
            line=dict(color="#fb7185", width=2),
        ))
        fig4.update_layout(
            template="plotly_dark", height=300,
            paper_bgcolor="#0f172a", plot_bgcolor="#0f172a",
            font=dict(family="Space Grotesk"),
            xaxis_title="Epoch", yaxis_title="MSE Loss",
            margin=dict(l=40, r=40, t=30, b=30),
        )
        fig4.update_yaxes(gridcolor="#1e293b")
        st.plotly_chart(fig4, use_container_width=True)
