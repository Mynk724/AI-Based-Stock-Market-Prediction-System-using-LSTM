# 📈 NSE / BSE LSTM Stock Predictor

End-to-end deep learning project for Indian stock market forecasting.
Built with TensorFlow/Keras, yfinance, Streamlit, and Plotly.

---

## Project Structure

```
nse_bse_predictor/
│
├── data/
│   ├── data_collector.py      # Layer 1  – Fetch OHLCV from Yahoo Finance
│   ├── data_preprocessor.py   # Layer 2  – Clean & sort data
│   ├── feature_engineer.py    # Layer 3  – 26 technical indicators
│   └── data_pipeline.py       # Layers 4-6 – Normalize, sequences, split
│
├── models/
│   ├── lstm_model.py          # Layers 7-12 – Build & train LSTM
│   └── evaluator.py           # Layers 13-14 – Predict & evaluate
│
├── utils/
│   └── plotting.py            # Layer 15 – Matplotlib charts
│
├── notebooks/
│   └── walkthrough.ipynb      # Step-by-step notebook for learning
│
├── app.py                     # Layer 16 – Streamlit dashboard
├── train.py                   # Master training script (CLI)
└── requirements.txt
```

---

## Quickstart

### Step 1 — Clone & enter the project folder
```bash
cd nse_bse_predictor
```

### Step 2 — Create a virtual environment (recommended)
```bash
python -m venv venv

# Activate on Linux/Mac:
source venv/bin/activate

# Activate on Windows:
venv\Scripts\activate
```

### Step 3 — Install dependencies
```bash
pip install -r requirements.txt
```

---

## Option A — Train via Command Line

```bash
# Default: Reliance Industries (NSE), 5 years of data
python train.py

# Specify any NSE stock
python train.py --ticker TCS.NS --period 5y --lookback 60 --epochs 100

# Specify a BSE stock
python train.py --ticker HDFCBANK.BO --period 3y

# With all options
python train.py \
  --ticker      INFY.NS \
  --period      5y \
  --lookback    60 \
  --epochs      100 \
  --batch_size  32 \
  --train_ratio 0.80 \
  --lr          0.001
```

### Common NSE Tickers
| Company              | Ticker        |
|----------------------|---------------|
| Reliance Industries  | RELIANCE.NS   |
| TCS                  | TCS.NS        |
| HDFC Bank            | HDFCBANK.NS   |
| Infosys              | INFY.NS       |
| ICICI Bank           | ICICIBANK.NS  |
| Bajaj Finance        | BAJFINANCE.NS |
| Wipro                | WIPRO.NS      |
| Nifty 50 Index       | ^NSEI         |
| Sensex               | ^BSESN        |

For BSE, replace `.NS` with `.BO` (e.g. `RELIANCE.BO`)

---

## Option B — Streamlit Web App

```bash
streamlit run app.py
```

Opens at **http://localhost:8501**

### App Features
- **Data Explorer tab** — Live candlestick chart, Bollinger Bands, RSI, MACD, Volume
- **Train Model tab** — Train LSTM with progress log directly in the browser
- **Predict tab** — Next-day price forecast with BUY / SELL / HOLD signal
- **Evaluation tab** — Actual vs Predicted chart, loss curves, RMSE / MAE / R²

---

## Option C — Jupyter Notebook (best for learning)

```bash
pip install jupyter
jupyter notebook notebooks/walkthrough.ipynb
```

Every layer is a separate cell with explanations.

---

## Understanding the Output

| Metric | What it means |
|--------|---------------|
| **RMSE** | Root Mean Squared Error in ₹ — lower is better |
| **MAE**  | Mean Absolute Error in ₹ — average prediction error |
| **MAPE** | Mean Absolute Percentage Error — e.g. 2.5% error |
| **R²**   | 0 to 1 — closer to 1 means better fit |
| **Direction Accuracy** | % of days the model correctly predicted up/down |

---

## Tips for Better Results

- Use **5y or 10y** of data — more data = better LSTM training
- **Lookback = 60** (days) is a good default; try 90 or 120 for smoother predictions
- Run for **100+ epochs** with early stopping — the model stops automatically at best weights
- Stocks with **high liquidity** (Nifty 50 stocks) give cleaner predictions
- Don't overtune — MAPE of 1-3% is realistic; below 1% is suspiciously overfit

---

## ⚠️ Disclaimer

This project is for **educational and learning purposes only**.
It is **not financial advice**. Do not use model predictions for real trading decisions.
