"""
utils/plotting.py
-----------------
Layer 15 – Visualization helpers (Matplotlib + Plotly).
Used by train.py for offline charts and by app.py for the dashboard.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.gridspec import GridSpec


# ── Matplotlib (offline / notebook) ──────────────────────────────────────────

def plot_actual_vs_predicted(
    dates: pd.DatetimeIndex,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    ticker: str = "",
    save_path: str = None,
):
    """
    Line chart: Actual close prices vs model predictions.
    """
    fig, ax = plt.subplots(figsize=(14, 5))
    fig.patch.set_facecolor("#0f172a")
    ax.set_facecolor("#0f172a")

    ax.plot(dates, y_true, color="#38bdf8", linewidth=1.8, label="Actual")
    ax.plot(dates, y_pred, color="#fbbf24", linewidth=1.4,
            linestyle="--", label="Predicted")

    ax.set_title(f"{ticker} — Actual vs Predicted Close Price",
                 color="#f1f5f9", fontsize=13, pad=12)
    ax.set_xlabel("Date",  color="#94a3b8")
    ax.set_ylabel("Price (₹)", color="#94a3b8")
    ax.tick_params(colors="#94a3b8")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    plt.xticks(rotation=30)
    ax.legend(facecolor="#1e293b", labelcolor="#f1f5f9")
    ax.spines[["top","right","left","bottom"]].set_color("#334155")
    ax.yaxis.grid(True, color="#1e293b", linewidth=0.7)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"[Plot] Saved → {save_path}")
    plt.show()


def plot_loss_curves(history: dict, save_path: str = None):
    """
    Training vs Validation loss curves from Keras history dict.
    """
    fig, ax = plt.subplots(figsize=(10, 4))
    fig.patch.set_facecolor("#0f172a")
    ax.set_facecolor("#0f172a")

    ax.plot(history["loss"],     color="#818cf8", label="Train Loss")
    ax.plot(history["val_loss"], color="#fb7185", label="Val Loss", linestyle="--")

    ax.set_title("Model Loss (MSE)", color="#f1f5f9", fontsize=12, pad=10)
    ax.set_xlabel("Epoch", color="#94a3b8")
    ax.set_ylabel("MSE", color="#94a3b8")
    ax.tick_params(colors="#94a3b8")
    ax.legend(facecolor="#1e293b", labelcolor="#f1f5f9")
    ax.spines[["top","right","left","bottom"]].set_color("#334155")
    ax.yaxis.grid(True, color="#1e293b", linewidth=0.7)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"[Plot] Saved → {save_path}")
    plt.show()


def plot_technical_overview(df: pd.DataFrame, ticker: str = "", days: int = 120):
    """
    4-panel chart: Candlestick + BB, RSI, MACD, Volume.
    Requires feature-engineered DataFrame.
    """
    d = df.tail(days)

    fig = plt.figure(figsize=(16, 10), facecolor="#0f172a")
    gs  = GridSpec(4, 1, figure=fig, height_ratios=[3, 1, 1, 1], hspace=0.08)
    axes = [fig.add_subplot(gs[i]) for i in range(4)]
    for ax in axes:
        ax.set_facecolor("#0f172a")
        ax.tick_params(colors="#94a3b8")
        ax.yaxis.grid(True, color="#1e293b", linewidth=0.6)
        ax.spines[["top","right","left","bottom"]].set_color("#334155")

    # Panel 1: Close + Bollinger Bands
    axes[0].plot(d.index, d["Close"],     color="#38bdf8", lw=1.8, label="Close")
    axes[0].plot(d.index, d["BB_Upper"],  color="#64748b", lw=0.8, linestyle="--")
    axes[0].plot(d.index, d["BB_Lower"],  color="#64748b", lw=0.8, linestyle="--")
    axes[0].fill_between(d.index, d["BB_Upper"], d["BB_Lower"],
                         alpha=0.08, color="#38bdf8")
    axes[0].plot(d.index, d["SMA_20"],    color="#f59e0b", lw=1, linestyle=":", label="SMA20")
    axes[0].plot(d.index, d["SMA_50"],    color="#a78bfa", lw=1, linestyle=":", label="SMA50")
    axes[0].set_title(f"{ticker} — Technical Overview", color="#f1f5f9", pad=8)
    axes[0].legend(facecolor="#1e293b", labelcolor="#f1f5f9", fontsize=8)
    axes[0].set_ylabel("Price (₹)", color="#94a3b8")

    # Panel 2: RSI
    axes[1].plot(d.index, d["RSI_14"], color="#a78bfa", lw=1.2)
    axes[1].axhline(70, color="#f87171", lw=0.8, linestyle="--")
    axes[1].axhline(30, color="#4ade80", lw=0.8, linestyle="--")
    axes[1].set_ylim(0, 100)
    axes[1].set_ylabel("RSI", color="#94a3b8", fontsize=8)

    # Panel 3: MACD
    axes[2].plot(d.index, d["MACD"],        color="#38bdf8", lw=1.2, label="MACD")
    axes[2].plot(d.index, d["MACD_Signal"], color="#fbbf24", lw=1.0, label="Signal")
    hist_colors = ["#4ade80" if v >= 0 else "#f87171" for v in d["MACD_Hist"]]
    axes[2].bar(d.index, d["MACD_Hist"], color=hist_colors, alpha=0.6, width=0.8)
    axes[2].axhline(0, color="#475569", lw=0.6)
    axes[2].set_ylabel("MACD", color="#94a3b8", fontsize=8)
    axes[2].legend(facecolor="#1e293b", labelcolor="#f1f5f9", fontsize=7)

    # Panel 4: Volume
    vol_colors = ["#4ade80" if c >= o else "#f87171"
                  for c, o in zip(d["Close"], d["Open"])]
    axes[3].bar(d.index, d["Volume"], color=vol_colors, alpha=0.8, width=0.8)
    axes[3].set_ylabel("Volume", color="#94a3b8", fontsize=8)

    for ax in axes[:-1]:
        ax.set_xticklabels([])
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    axes[-1].xaxis.set_major_locator(mdates.MonthLocator(interval=1))
    plt.xticks(rotation=30, color="#94a3b8")

    plt.tight_layout()
    plt.show()
